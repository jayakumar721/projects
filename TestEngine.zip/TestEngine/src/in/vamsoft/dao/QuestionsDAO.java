package in.vamsoft.dao;

import java.util.List;

import in.vamsoft.model.Question;

public interface QuestionsDAO {

  List<Question> getQuestions();

}